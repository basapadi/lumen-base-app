<?php

return [
    'timezone' => 'Asia/Jakarta',
    'env' => env('APP_ENV', 'local')
];