<?php
namespace App\Statics;

/**
 * Description of Product Type Static
 *
 * @author bachtiarpanjaitan <bachtiarpanjaitan0@gmail.com>
 * @since 4 April 2023
 */
class ProductTypeStatic {
    
    static $SINGLE = 0;
    static $GROUP = 1;
    
    
    
}